def sum_numbers(numbers=None):
    # Hi from the command line
    pass
